// The deployed game is the baseline. Browser decisions are previews until a changeset is applied.
import { useState } from 'react'
import type { Word, Sources } from '../content/types'
import type { SourceRecord } from '../sources/types'
import type { RepoState } from '../sources/changeset'
import { audioReliable } from '../content/entries'
import { EXPLANATIONS } from '../content/index'
import { eligibleUses } from '../content/recordings'
import { effectiveRecording, effectiveSelection, opStatus, type WorkingState } from './store'

/** Highlight the changed middle; unchanged prefix/suffix stay legible even on a phone. This is a text diff, not a sense judgment. */
function ChangedText({ value, baseline }: { value: string; baseline: string }) {
  if (value === baseline) return <>{value}</>
  const a = Array.from(baseline), b = Array.from(value)
  let start = 0, end = 0
  while (start < a.length && start < b.length && a[start] === b[start]) start++
  while (end < a.length - start && end < b.length - start && a[a.length - 1 - end] === b[b.length - 1 - end]) end++
  return <>{b.slice(0, start).join('')}<mark>{b.slice(start, b.length - end).join('') || '(text removed)'}</mark>{end ? b.slice(-end).join('') : ''}</>
}

export function EntryOverview({ word, record, repo, working, sources, words, records }: {
  word: Word; record: SourceRecord; repo: RepoState; working: WorkingState; sources: Sources; words: Word[]; records: Map<string, SourceRecord>
}) {
  const [onlyChanges, setOnlyChanges] = useState(true)
  const sourceName = sources[record.source]?.title ?? record.source
  const label = record.candidate.meanings.join(' / ') || 'Not provided by this source'
  const reading = record.candidate.readings.join(' / ') || 'Not provided by this source'
  const { selection, working: meaningDraft } = effectiveSelection(working, repo, word.id, 'meaning')
  const { recording, working: audioDraft } = effectiveRecording(working, repo, word.id)
  const currentClip = repo.recordings.recordings.find(x => x.entry === word.id && x.scope === 'word')
  const committedChoice = repo.selections.selections.find(x => x.entry === word.id && x.field === 'meaning')
  const fieldOp = working.ops[`field:${word.id}:meaning`]
  const audioOp = working.ops[`recording:${word.id}`]
  const draftProblems = [fieldOp, audioOp].filter(x => x && opStatus(x, repo, records) !== 'ok')
  const nextMeaning = meaningDraft && selection?.choice !== 'game' ? selection?.value ?? word.meaning : word.meaning
  const nameOf = (source?: string) => source ? sources[source]?.title ?? source : 'Game editorial content'
  const audioLabel = (clip: typeof recording) => {
    if (!clip) return audioReliable(word, words) ? 'Text-to-speech (when a Mandarin voice is available)' : 'No audio: text-to-speech is disabled for this entry'
    const available = eligibleUses(clip, word).has('display')
    return `${nameOf(clip.provenance.source)} · ${clip.reading.verified ?? clip.reading.declared ?? 'reading unknown'}${available ? '' : ' · unavailable; no TTS fallback'}`
  }
  const explanation = EXPLANATIONS[word.id]
  const rows = [
    { field: 'Short meaning', current: word.meaning, source: label },
    { field: 'Pinyin', current: word.pinyin, source: reading }
  ]
  return <section className="rv-card rv-overview" aria-label="Current game content and draft preview">
    <div className="rv-overview-title"><h2>Used in the game today</h2><span className="rv-pill">This deployed build</span></div>
    <p className="rv-entry-title"><span lang="zh-CN">{word.hanzi}</span> <b>{word.pinyin}</b></p>
    <p className="rv-current-meaning">{word.meaning}</p>
    <p className="rv-small">Meaning origin: {committedChoice?.choice === 'source' || committedChoice?.choice === 'edited' ? nameOf(committedChoice.provenance?.source) : 'Game editorial content'}{committedChoice?.choice === 'edited' ? ' (adapted wording)' : ''}. {word.review?.status ?? 'Unreviewed'}.</p>
    <p><b>Usage note:</b> {word.note}</p>
    <p className="rv-small"><b>Current audio:</b> {audioLabel(currentClip ?? null)}.</p>
    <details><summary>Current explanation and examples</summary>
      {!explanation && <p className="rv-small">No additional explanation.</p>}
      {explanation?.summary && <p>{explanation.summary}</p>}
      {explanation?.sections.map((s, i) => <div key={i}>
        {s.heading && <h3>{s.heading}</h3>}
        {s.type === 'text' ? <p>{s.body}</p> : s.type === 'tips' ? <ul>{s.items.map((x, j) => <li key={j}>{x}</li>)}</ul> : s.type === 'examples' ? <ul>{s.items.map((x, j) => <li key={j}><span lang="zh-CN">{x.zh}</span><br />{x.pinyin}<br />{x.en}{x.note && <p>{x.note}</p>}</li>)}</ul> : <><p>{s.intro}</p><ul>{(s.type === 'breakdown' ? s.parts : s.items).map((x, j) => <li key={j}>{x.char} {x.pinyin} — {x.meaning}{x.note && ` · ${x.note}`}</li>)}</ul></>}
      </div>)}
    </details>

    <h3>Compare with {sourceName}</h3>
    <p className="rv-small">Browsing this collection does not select it for the game. Highlighting shows text differences, not which meaning is better.</p>
    <label className="rv-diff-toggle"><input type="checkbox" checked={onlyChanges} onChange={e => setOnlyChanges(e.target.checked)} /> Show differences only</label>
    {onlyChanges && rows.every(x => x.current === x.source) && <p>Short meaning and pinyin have identical text.</p>}
    <div className="rv-diff-list">{rows.filter(x => !onlyChanges || x.current !== x.source).map(x => <div className="rv-diff-field" key={x.field}>
      <b>{x.field}{x.current === x.source ? ' · identical text' : ' · different text'}</b>
      <div className="rv-diff-pair"><div><small>Game today</small><ChangedText value={x.current} baseline={x.source} /></div><div><small>Source candidate</small><ChangedText value={x.source} baseline={x.current} /></div></div>
    </div>)}</div>
    <p className="rv-small">Usage note and explanation: not changed by source selection. Source examples are separate candidates below.</p>

    <div className="rv-draft-result" role="status" aria-live="polite">
      <h3>Your proposed result</h3>
      <p><b>{meaningDraft || audioDraft ? 'Draft saved in this browser — game unchanged' : 'No wording or audio changes drafted for this entry'}</b></p>
      <p>Short meaning: <ChangedText value={nextMeaning} baseline={word.meaning} />{meaningDraft && nextMeaning === word.meaning && ' (wording unchanged)'}</p>
      <p>Audio: {audioDraft ? audioLabel(recording) : 'Keep current audio'}</p>
      <p className="rv-small">Pinyin, usage note, explanation and lessons stay as shown above. Linking a record alone changes none of these fields.</p>
      {draftProblems.length > 0 && <p className="rv-warn">A draft needs reassessment before it can be applied. This preview is not a valid applied change yet.</p>}
      <p className="rv-small">To update the game: export from “Proposed changes”, apply the changeset in the repository, then deploy.</p>
    </div>
  </section>
}
